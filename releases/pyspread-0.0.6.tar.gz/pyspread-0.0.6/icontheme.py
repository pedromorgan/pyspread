# Toolbar items
import wx

icon_size = (32, 32)
icons = {"FileNew": "./icons/actions/filenew.png", \
         "FileOpen": "./icons/actions/fileopen.png", \
         "FileSave": "./icons/actions/filesave.png", \
         "FilePrint": "./icons/actions/fileprint.png", \
         "EditCut": "./icons/actions/edit-cut.png", \
         "EditCopy": "./icons/actions/edit-copy.png", \
         "EditCopyRes": "./icons/actions/edit-copy results.png", \
         "EditPaste": "./icons/actions/edit-paste.png"}
