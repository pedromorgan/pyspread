#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright 2008 Martin Manns
# Distributed under the terms of the GNU General Public License

"""
    pyspread is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    pyspread is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys, itertools, numpy\
# import gmpy, rpy # This will be moved into the GUI
from types import IntType, FunctionType

class Grid(object):
    """ The central grid object that consists of 
        a string   grid sgrid and
        a function grid fgrid. """
    def __init__(self, parent, dimensions=(10,10,10)):
        global S
        S = self
        self.isrecursion = 0
        self.name = "S"
        self.dimensions = dimensions
        self.fgrid = numpy.zeros(self.dimensions, dtype="O")
        self.sgrid = numpy.zeros(self.dimensions, dtype="S")
        self.sgrid = numpy.array(self.sgrid, dtype="O")

    def __getitem__(self, slice):
        if not self.isrecursion:
            self.__setXYZ(slice)
        self.isrecursion += 1
        fgrid_slice = self.fgrid[slice]
        if type(fgrid_slice) is FunctionType:
            fgrid_slice = numpy.array([fgrid_slice], dtype="O")
        try:
            no_different_funcs = 0
            if fgrid_slice == 0:
                self.isrecursion -= 1
                return ''
        except: pass # We got an array here
        try:
            no_different_funcs = len(set(fgrid_slice.flat) - set([0]))
        except: pass
        if no_different_funcs: # Array is not empty
            def call(func):
                functype = type(func)
                if func is 0: return 0
                elif functype is FunctionType:
                    try: res = func()
                    except Exception, x: 
                        print x
                        res = x
                    return res
                else: return func
            func_slice = numpy.array(self.fgrid[slice])
            try: func_it = func_slice.flat
            except: func_it = [func_slice]
            result = numpy.array([call(f) for f in func_it], dtype="O")
            oneele = False
            try: oneele = (len(result) == 1)
            except: pass
            if oneele: res = result[0]
            else:      res = result.reshape(func_slice.shape)
            self.isrecursion -= 1
            return res
        self.isrecursion -= 1
        return fgrid_slice
    
    def __setitem__(self, slice, value):
        self.sgrid.__setitem__(slice, value)

    def __setXYZ(self, slice):
            global X
            global Y
            global Z
            X, Y, Z = slice

    def get_function_cell_indices(self):
        """ Get all fgrid cells with a function instead of dummy 0 """
        return set(zip(*numpy.nonzero(self.sgrid))+zip(*numpy.nonzero(self.fgrid)))

    def eval_function_grid(self):
        """ Eval the function grid from the string grid """
        sgrid = self.sgrid
        string_elements = set(zip(*numpy.nonzero(sgrid))+zip(*numpy.nonzero(self.fgrid)))
        global S
        S = self
        for i in string_elements:
            self.fgrid[i] = eval("lambda "+self.name+"=S:"+sgrid[i], globals())
