#!/usr/bin/env python

from distutils.core import setup
setup(name='pyspread',
      version='0.02',
      description='A spreadsheet that accepts a pure python expression in each cell.',
      license='GPL v3 :: GNU General Public License',
      classifiers=[ 'Development Status :: 3 - Alpha',
                    'Intended Audience :: End Users/Desktop',
      ],
      author='Martin Manns',
      author_email='mmanns@gmx.net',
      url='http://sourceforge.net/projects/pyspread/',
      package_dir={'': ''},
      py_modules=['pyspread', 'pysgrid', 'mygrid'],
      data_files=[('icons', ['icons/pyspread.png']),
                  ('readme', ['README']),
                  ('copying',['COPYING'])]      
     )
