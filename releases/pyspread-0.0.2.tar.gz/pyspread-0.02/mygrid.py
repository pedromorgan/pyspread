#!/usr/bin/env python
# -*- coding: utf-8 -*-
# This file is based on the wxpython demo

# Modifications:
# Copyright 2008 Martin Manns
# Distributed under the terms of the GNU General Public License

"""
    pyspread is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    pyspread is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
"""

import wx
import wx.grid

DEBUG = True

class MyGrid(wx.grid.Grid):
    """ A Copy&Paste enabled grid class"""
    def __init__(self, parent, id=wx.NewId(), pos=(0,0), size=(1,1), style=-1, mainwindow = None):
        self.parent = parent
        self.mainwindow = mainwindow 
        wx.grid.Grid.__init__(self, parent, id, pos, size, style)
        wx.EVT_KEY_DOWN(self, self.OnKey)

    def get_selected_rows_cols(self):
        """ Get the number of selected rows and cols, 1 if no selection """
        try:    rows = self.GetSelectionBlockBottomRight()[0][0] - \
                       self.GetSelectionBlockTopLeft()[0][0] + 1
        except IndexError: rows = 1
        try:    cols = self.GetSelectionBlockBottomRight()[0][1] - \
                       self.GetSelectionBlockTopLeft()[0][1] + 1
        except IndexError: cols = 1        
        return rows, cols
            
    def get_currentcell(self):
        # Get cursor position
        row = self.GetGridCursorRow()
        col = self.GetGridCursorCol()
        return row, col
        
    def OnKey(self, event):
        ##print event.GetKeyCode()
        # If Ctrl+X is pressed...
        if event.ControlDown() and event.GetKeyCode() == 88:
            if DEBUG: print "Ctrl+X"
            # Call copy method
            self.cut()
        
        # If Ctrl+C is pressed...
        if not event.ShiftDown() and event.ControlDown() and event.GetKeyCode() == 67:
            if DEBUG: print "Ctrl+C"
            # Call copy method
            self.copy(source=lambda x,y:self.mainwindow.grid.sgrid[x, y, self.mainwindow.current_table])
        
        # If Shift+Ctrl+C is pressed...
        if event.ShiftDown() and event.ControlDown() and event.GetKeyCode() == 67:
            if DEBUG: print "Shift+Ctrl+C"
            # Call copy method
            self.copy(source=self.GetCellValue)
        
        # If Ctrl+V is pressed...
        if event.ControlDown() and event.GetKeyCode() == 86:
            if DEBUG: print "Ctrl+V"
            # Call paste method
            self.paste()
            
        # If Supr is presed
        if event.GetKeyCode() == 127:
            if DEBUG: print "Supr"
            # Call delete method
            self.delete()
            
        # Skip other Key events
        if event.GetKeyCode():
            event.Skip()
            return

    def cut(self):
        self.copy(source=lambda x,y:self.mainwindow.grid.sgrid[x, y, self.mainwindow.current_table])
        self.delete()

    def copy(self, source=None):
        """ Copy method.
            Source can be sgrid, fgrid or the displayed wxGrid """
        
        rows, cols = self.get_selected_rows_cols()

        # Data variable contain text that must be set in the clipboard
        data = ''
        
        # For each cell in selected range append the cell value in the data variable
        # Tabs '\t' for cols and '\r' for rows
        for r in xrange(rows):
            for c in xrange(cols):
                try: data = data + source(self.GetSelectionBlockTopLeft()[0][0] + r, \
                                          self.GetSelectionBlockTopLeft()[0][1] + c)
                except IndexError: 
                    row, col = self.get_currentcell()
                    data = data + source(row + r, col + c)
                if c < cols - 1:
                    data = data + '\t'
            data = data + '\n'
        # Create text data object
        clipboard = wx.TextDataObject()
        # Set data object value
        clipboard.SetText(data)
        # Put the data in the clipboard
        if wx.TheClipboard.Open():
            wx.TheClipboard.SetData(clipboard)
            wx.TheClipboard.Close()
        else:
            wx.MessageBox("Can't open the clipboard", "Error")
            
    def paste(self):
        clipboard = wx.TextDataObject()
        if wx.TheClipboard.Open():
            wx.TheClipboard.GetData(clipboard)
            wx.TheClipboard.Close()
        else:
            wx.MessageBox("Can't open the clipboard", "Error")
        data = clipboard.GetText()
        table = []
        y = -1
        # Convert text in a array of lines
        for r in data.splitlines():
            y = y +1
            x = -1
            # Convert c in a array of text separated by tab
            for c in r.split('\t'):
                x = x +1
                self.SetCellValue(self.GetGridCursorRow() + y, self.GetGridCursorCol() + x, c)
                if c == "": 
                    self.mainwindow.grid.fgrid[self.GetGridCursorRow() + y, self.GetGridCursorCol() + x, self.mainwindow.current_table] = 0
                self.mainwindow.grid.sgrid[self.GetGridCursorRow() + y, self.GetGridCursorCol() + x, self.mainwindow.current_table] = c
        self.mainwindow.update_grid()
                
    def delete(self):
        rows, cols = self.get_selected_rows_cols()
        # Clear cells contents
        for r in range(rows):
            for c in range(cols):
                if DEBUG: print r,c
                try: row, col = self.GetSelectionBlockTopLeft()[0][0], \
                                self.GetSelectionBlockTopLeft()[0][1]
                except IndexError: row, col = self.get_currentcell()
                self.mainwindow.grid.fgrid[row + r, col + c, self.mainwindow.current_table] = 0
                self.mainwindow.grid.sgrid[row + r, col + c, self.mainwindow.current_table] = ''
                self.SetCellValue(row + r, col + c, '')


        
