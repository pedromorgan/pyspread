#!/usr/bin/env python

from distutils.core import setup

setup(name='pyspread',
      version='0.0.9',
      description='A spreadsheet that accepts a pure python expression in each cell.',
      license='GPL v3 :: GNU General Public License',
      classifiers=[ 'Development Status :: 3 - Alpha',
                    'Intended Audience :: End Users/Desktop',
      ],
      author='Martin Manns',
      author_email='mmanns@gmx.net',
      url='http://sourceforge.net/projects/pyspread/',
      packages=['pyspread'],
      package_dir={'pyspread': '.'},
      scripts=['pyspread.py'],
      package_data={'pyspread': ['icons/*.png', 'icons/actions/*.png' ,\
                                 'test.pys', 'test.csv', 'test2.csv', \
                                 'README', 'COPYING']},
)

import distutils.sysconfig
try:
    pthfile = open(distutils.sysconfig.get_python_lib()+"/pyspread.pth",'w')
    pthfile.write("pyspread")
    pthfile.close()
except: print 'Creation of ' + distutils.sysconfig.get_python_lib() + ' pyspread.pth failed.'
