# Toolbar items

import distutils.sysconfig
LIBPREFIX = './'
try:
    dummy = open("./icons/actions/filenew.png",'r')
    dummy.close()
except:
    LIBPREFIX = distutils.sysconfig.get_python_lib() + '/pyspread/'

icon_size = (32, 32)
icons = {"FileNew": LIBPREFIX + "icons/actions/filenew.png", \
         "FileOpen": LIBPREFIX + "icons/actions/fileopen.png", \
         "FileSave": LIBPREFIX + "icons/actions/filesave.png", \
         "FilePrint": LIBPREFIX + "icons/actions/fileprint.png", \
         "EditCut": LIBPREFIX + "icons/actions/edit-cut.png", \
         "EditCopy": LIBPREFIX + "icons/actions/edit-copy.png", \
         "EditCopyRes": LIBPREFIX + "icons/actions/edit-copy results.png", \
         "EditPaste": LIBPREFIX + "icons/actions/edit-paste.png"}
