#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright 2011 Martin Manns
# Distributed under the terms of the GNU General Public License

# --------------------------------------------------------------------
# pyspread is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pyspread is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with pyspread.  If not, see <http://www.gnu.org/licenses/>.
# --------------------------------------------------------------------

"""
test_main_window_actions.py
===========================

Unit tests for _main_window_actions.py

"""

import os
from sys import path
import csv

test_path = os.path.dirname(os.path.realpath(__file__))
path.insert(0, test_path + "/../..")

import wx
app = wx.App()

from src.gui._main_window import MainWindow
from src.gui._grid import Grid
from src.model.model import DataArray
from src.lib.selection import Selection
from src.lib.testlib import main_window, code_array, grid_values, restore_basic_grid
from src.lib.testlib import params, pytest_generate_tests, basic_setup_test

from src.actions._main_window_actions import CsvInterface, TxtGenerator


class TestCsvInterface(object):
    def setup_method(self, method):
        self.test_filename = "test.csv"
        self.test_filename2 = "test_one_col.csv"
        self.test_filename3 = "test_write.csv"
        
        
    def _get_csv_gen(self, filename, digest_types=None):
        test_file = open(filename)
        dialect = csv.Sniffer().sniff(test_file.read(1024))
        test_file.close()
        
        if digest_types is None:
            digest_types = [type(1)]
            
        has_header = False

        return CsvInterface(main_window, filename, 
                            dialect, digest_types, has_header)

    def test_get_csv_cells_gen(self):
        """Tests generator from csv content"""
        
        csv_gen = self._get_csv_gen(self.test_filename)
        
        column = xrange(100)
        
        cell_gen = csv_gen._get_csv_cells_gen(column)
        
        for i, cell in enumerate(cell_gen):
            assert str(i) == cell
        

    def test_iter(self):
        """Tests csv generator"""
        
        csv_gen = self._get_csv_gen(self.test_filename)
        
        assert [list(col) for col in csv_gen] == [['1', '2'], ['3', '4']]
        
        csv_gen = self._get_csv_gen(self.test_filename2, digest_types = \
                  [type("")])
        
        
        for i, col in enumerate(csv_gen):
            list_col = list(col)
            if i < 6:
                assert list_col == ["'" + str(i + 1) + "'", "''"]
            else:
                assert list_col == ["''", "''"]
    
    def test_write(self):
        """Tests writing csv file"""
        
        csv_gen = self._get_csv_gen(self.test_filename)
        csv_gen.path = self.test_filename3
        
        csv_gen.write(xrange(100) for _ in xrange(100))
        
        infile = open(self.test_filename3)
        content = infile.read()
        assert content[:10] == "0\t1\t2\t3\t4\t"
        infile.close()


class TestTxtGenerator(object):
    """Tests generating txt files"""
    
    def setup_method(self, method):
        main_window = MainWindow(None, -1)
        
        self.test_filename = "test.csv"
        self.test_filename_single_col = "large.txt"
        self.test_filename_notthere = "notthere.txt"
        self.test_filename_bin = "test1.pys"
        
    
    def test_iter(self):
        """Tests iterating over text files"""
        
        # Correct file with 2 columns
        
        txt_gen = TxtGenerator(main_window, self.test_filename)
        
        assert list(list(line_gen) for line_gen in txt_gen) == \
                [['1', '2'], ['3', '4']]
        
        # Correct file with 1 column
        
        txt_gen = TxtGenerator(main_window, self.test_filename_single_col)
        
        txt_list = []
        for i, line_gen in enumerate(txt_gen):
            txt_list.append(list(line_gen))
            if i == 3:
                break
        assert txt_list == [['00'], ['877452769922012304'], 
	  ['877453769923767209'], ['877454769925522116']]
        
        # Missing file
        
        txt_gen = TxtGenerator(main_window, self.test_filename_notthere)
        assert list(txt_gen) == []
        
        # Binary file
        
        txt_gen = TxtGenerator(main_window, self.test_filename_bin)
        
        has_value_error = False
        
        try: 
            print [list(ele) for ele in txt_gen]
            
        except ValueError:
            has_value_error = True
        
        ##TODO: This still fails and I do not know how to identify binary files
        ##assert has_value_error # ValueError should occur on binary file


class TestExchangeActions(object):
    """Does nothing because of User interaction in this method"""
        
    pass

class TestPrintActions(object):
    """Does nothing because of User interaction in this method"""
        
    pass
    
class TestClipboardActions(object):
    """Clipboard actions test class. Does not use actual clipboard."""
    
    param_copy = [ \
      {'selection': Selection([], [], [], [], [(0, 0)]), 'result': "'Test'"},
      {'selection': Selection([], [], [], [], [(999, 0)]), 'result': "1"},
      {'selection': Selection([], [], [], [], [(999, 99)]), 'result': "$^%&$^"},
      {'selection': Selection([], [], [], [], [(0, 1)]), 'result': "1"},
      {'selection': Selection([(0, 1)], [(0, 1)], [], [], []), 'result': "1"},
      {'selection': Selection([(0, 1)], [(1, 1)], [], [], []), 
       'result': "1\n3"},
      {'selection': Selection([(0, 1)], [(1, 2)], [], [], []), 
       'result': "1\t2\n3\t4"},
    ]
    
    @params(param_copy)
    def test_cut(self, selection, result):
        """Test cut, i. e. copy and deletion"""
        
        restore_basic_grid()
        
        assert main_window.actions.cut(selection) == result
        
        (top, left), (bottom, right) = selection.get_bbox()
        
        for row in xrange(top, bottom + 1):
            for col in xrange(left, right + 1):
                if (row, col) in selection:
                    key = row, col, 0
                    assert code_array[key] is None
                    code_array[key] = grid_values[key]
    
    @params(param_copy)
    def test_copy(self, selection, result):
        """Test copy of single values, lists and matrices"""
        
        restore_basic_grid()
        
        assert main_window.actions.copy(selection) == result

    param_copy_result = [ \
        {'selection': Selection([], [], [], [], [(0, 0)]), 'result': "Test"},
        {'selection': Selection([], [], [], [], [(999, 0)]), 'result': "1"},
        {'selection': Selection([], [], [], [], [(999, 99)]),
                'result': "invalid syntax (<string>, line 1)"},
    ]
    
    @params(param_copy_result)
    def test_copy_result(self, selection, result):
        """Test copy results of single values, lists and matrices"""
        
        restore_basic_grid()
        
        assert main_window.actions.copy_result(selection) == result
        
        
## TODO: Test hangs when doing py.test for all tests in directory
    param_paste = [ \
        {'target': (0, 0), 'data': "1", 
         'test_key': (0, 0, 0), 'test_val': "1"},
        {'target': (25, 25), 'data': "1\t2", 
         'test_key': (25, 25, 0), 'test_val': "1"}, 
        {'target': (25, 25), 'data': "1\t2", 
         'test_key': (25, 26, 0), 'test_val': "2"}, 
        {'target': (25, 25), 'data': "1\t2", 
         'test_key': (26, 25, 0), 'test_val': None},
        {'target': (25, 25), 'data': "1\t2\n3\t4", 
         'test_key': (25, 25, 0),  'test_val':"1"}, 
        {'target': (25, 25), 'data': "1\t2\n3\t4", 
         'test_key': (25, 26, 0),  'test_val':"2"},
        {'target': (25, 25), 'data': "1\t2\n3\t4", 
         'test_key': (26, 25, 0),  'test_val':"3"},
        {'target': (27, 27), 'data': u"ä", 
         'test_key': (27, 27, 0), 'test_val': u"ä"},
    ]
    
    @params(param_paste)
    def test_paste(self, target, data, test_key, test_val):
        """Test paste of single values, lists and matrices"""
        
        restore_basic_grid()
        
        basic_setup_test(main_window.actions.paste, test_key, test_val, 
                         target, data)
        
class TestMacroActions(object):
    """Unit tests for macro actions"""
    
    macros = "def f(x): return x * x"
    
    def test_replace_macros(self):
        main_window.actions.replace_macros(self.macros)
        
        assert main_window.grid.code_array.macros == self.macros
        main_window.actions.replace_macros("")

    def test_execute_macros(self):
        
        # Unsure how to test since macros are not global ion py.test
        
        pass
        
    param_open_macros = [ \
        {'filename': "macrotest2.py"},
    ]
    
    @params(param_open_macros)
    def test_open_macros(self, filename):
        
        testmacro_infile = open(filename)
        testmacro_string = "\n" + testmacro_infile.read()
        testmacro_infile.close()
        
        main_window.actions.open_macros(filename)
        
        macros = main_window.grid.code_array.macros 
        
        assert testmacro_string == macros
        
    def test_save_macros(self):
        # TODO: Save macros is pretty direct so that the necessary file
        # protection actions are not yet implemented --> No tests yet
        pass

class TestHelpActions(object):
    """Does nothing because of User interaction in this method"""
        
    pass
    
