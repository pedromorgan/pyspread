#!/usr/bin/env python

from pyspread import *

if __name__ == "__main__":
    main()
