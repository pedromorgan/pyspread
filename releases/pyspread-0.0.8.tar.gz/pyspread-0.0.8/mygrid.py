#!/usr/bin/env python
# -*- coding: utf-8 -*-
# This file is based on the wxpython demo

# Modifications:
# Copyright 2008 Martin Manns
# Distributed under the terms of the GNU General Public License

"""
    pyspread is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    pyspread is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
"""

import wx
import wx.grid

DEBUG = True

class MyGrid(wx.grid.Grid):
    """ A Copy&Paste enabled grid class"""
    def __init__(self, parent, id=wx.NewId(), pos=(0,0), size=(1,1), style=0, mainwindow = None):
        self.parent = parent
        self.mainwindow = mainwindow
        self.copy_selection = [] # Cells from last copy operation 
        wx.grid.Grid.__init__(self, parent, id, pos, size, style)
        wx.EVT_KEY_DOWN(self, self.OnKey)

    def get_selected_rows_cols(self, selection = None):
        """ Get the slices of selected rows and cols, None if no selection """
        if selection is None: selection = self.get_selection()
        try: rowslice = slice(min(c[0] for c in selection), \
                              max(c[0] for c in selection) + 1)
        except IndexError: rowslice = None
        try: colslice = slice(min(c[1] for c in selection), \
                              max(c[1] for c in selection) + 1)
        except IndexError: colslice = None
        return rowslice, colslice
    
    def get_selection(self):
        """ Returns an index list of all cells that are selected in the grid.
        All selection types are considered equal. If no cells are selected,
        the current cell is returned."""
                
        # GetSelectedCells: individual cells selected by ctrl-clicking
        # GetSelectedRows: rows selected by clicking on the labels
        # GetSelectedCols: cols selected by clicking on the labels
        # GetSelectionBlockTopLeft
        # GetSelectionBlockBottomRight: For blocks of cells selected by dragging 
        # across the grid cells.
              
        dimx, dimy = self.parent.grid.dimensions[:2]        
        selection = []
        selection += self.GetSelectedCells()
        selected_rows = self.GetSelectedRows()
        selected_cols = self.GetSelectedCols()
        selection += list((row, y) for row in selected_rows for y in xrange(dimy))
        selection += list((x, col) for col in selected_cols for x in xrange(dimx))
        for tl,br in zip(self.GetSelectionBlockTopLeft(), self.GetSelectionBlockBottomRight()):
            selection += [(x,y) for x in xrange(tl[0],br[0]+1) for y in xrange(tl[1], br[1]+1)]
        if selection == []:
            selection = [(self.get_currentcell())]
        selection = sorted(list(set(selection)))
        print selection
        return selection
                    
    def get_currentcell(self):
        # Get cursor position
        row = self.GetGridCursorRow()
        col = self.GetGridCursorCol()
        return row, col
        
    def OnKey(self, event):
        ##print event.GetKeyCode()
        # If Ctrl+X is pressed...
        if event.ControlDown() and event.GetKeyCode() == 88:
            if DEBUG: print "Ctrl+X"
            # Call copy method
            self.cut()
        
        # If Ctrl+C is pressed...
        if not event.ShiftDown() and event.ControlDown() and event.GetKeyCode() == 67:
            if DEBUG: print "Ctrl+C"
            # Call copy method
            self.copy(source=self.mainwindow.grid.sgrid)
        
        # If Shift+Ctrl+C is pressed...
        if event.ShiftDown() and event.ControlDown() and event.GetKeyCode() == 67:
            if DEBUG: print "Shift+Ctrl+C"
            # Call copy method
            self.copy(source=self.grid)
        
        # If Ctrl+V is pressed...
        if event.ControlDown() and event.GetKeyCode() == 86:
            if DEBUG: print "Ctrl+V"
            # Call paste method
            self.paste()
            
        # If Supr is presed
        if event.GetKeyCode() == 127:
            if DEBUG: print "Supr"
            # Call delete method
            self.delete()
            
        # Skip other Key events
        if event.GetKeyCode():
            event.Skip()
            return

    def cut(self):
        """ Cuts TextCtrlSelection if present 
            else cuts Grid cells
            Source can be sgrid, fgrid or the displayed wxGrid """
        self.copy(source=self.mainwindow.grid.sgrid)
        focus = self.parent.FindFocus()
        if isinstance(focus, wx.TextCtrl):
            self.selection_replace(focus, "")
        else:
            self.delete()

    def getselectiondata(self, source, rowslice, colslice):
        """ Returns 2D array of source data that matches the current selection in the grid."""
        data = source[rowslice, colslice, self.mainwindow.current_table]
        # Now eliminate empty 0 "functions"
        flatdata = data.flatten()
        fgrid_data = self.mainwindow.grid.fgrid[rowslice, colslice, self.mainwindow.current_table]
        for i,func in enumerate(fgrid_data.flat):
            if func == 0: 
                flatdata[i] = ''
        data = flatdata.reshape(data.shape)
        return data

    def copy(self, source=None):
        """ Copies TextCtrlSelection if present 
            else copies Grid cells
            Source can be sgrid, fgrid"""
        if source is None: source = self.mainwindow.grid.sgrid
        focus = self.parent.FindFocus()
        if isinstance(focus, wx.TextCtrl):
            sel = focus.GetStringSelection()
            if sel != "":
                clipboard_data = sel
                self.copy_selection = []
            else: return 0
        else:            
            selection = self.get_selection()
            rowslice, colslice = self.get_selected_rows_cols(selection)
            data = self.getselectiondata(source, rowslice, colslice)
            clipboard_data = "\n".join("\t".join(str(d) for d in datarow) for datarow in data)
            self.copy_selection = [(cell[0]-rowslice.start, cell[1]-colslice.start) for cell in selection]
        if DEBUG: print clipboard_data
        # Create text data object
        clipboard = wx.TextDataObject()
        # Set data object value
        try: clipboard.SetText(clipboard_data)
        except UnboundLocalError: pass
        # Put the data in the clipboard
        if wx.TheClipboard.Open():
            wx.TheClipboard.SetData(clipboard)
            wx.TheClipboard.Close()
        else:
            wx.MessageBox("Can't open the clipboard", "Error")

            
    def paste(self):
        """ Pastes into TextCtrl if active else pastes to grid
        """
        clipboard = wx.TextDataObject()
        if wx.TheClipboard.Open():
            wx.TheClipboard.GetData(clipboard)
            wx.TheClipboard.Close()
        else:
            wx.MessageBox("Can't open the clipboard", "Error")
        data = clipboard.GetText()            
        
        focus = self.parent.FindFocus()
        if isinstance(focus, wx.TextCtrl):
            self.selection_replace(focus, data)
        else: # We got a grid selection so we paste into the grid
            table = []
            x = -1
            # Convert text in a array of lines
            line_list = data.splitlines()
            try:
                if data[-1] == '\n': line_list.append('')
            except IndexError: pass
            for r in line_list:
                x = x +1
                y = -1
                # Convert c in a array of text separated by tab
                col_list = r.split('\t')
                try:
                    if r[-1] == '\t': col_list.append('')
                except IndexError: pass
                for c in col_list:
                    print "c:",c
                    y = y +1
                    if self.copy_selection == [] or (x,y) in self.copy_selection:
                        self.SetCellValue(self.GetGridCursorRow() + x, self.GetGridCursorCol() + y, c)
                        if c == "": 
                            self.mainwindow.grid.fgrid[self.GetGridCursorRow() + x, self.GetGridCursorCol() + y, self.mainwindow.current_table] = 0
                        self.mainwindow.grid.sgrid[self.GetGridCursorRow() + x, self.GetGridCursorCol() + y, self.mainwindow.current_table] = c
            self.mainwindow.update_grid()
            
    def selection_replace(self, editor, data):
        """ Replaces a selection in a TextCtrl with inserted data
            *** This should be moved into a custom TextCtrl class ***
        """
        inspoint = int(editor.InsertionPoint)
        sel_begin, sel_end = editor.GetSelection()
        #print sel_begin, sel_end
        if sel_begin != sel_end and inspoint > sel_begin:
            inspoint = inspoint - min(abs(sel_end - sel_begin), abs(inspoint - sel_begin))
        oldval = editor.GetValue()[:sel_begin] + editor.GetValue()[sel_end:]
        newval = oldval[:inspoint] + data + oldval[inspoint:]
        editor.SetValue(newval)
        editor.SetInsertionPoint(inspoint + len(data))
        editor.SetSelection(inspoint, inspoint + len(data))
        
    def delete(self, selection=None):
        if selection is None:
            selection = self.get_selection()
        for cell in selection:
            self.mainwindow.grid.fgrid[cell[0], cell[1], self.mainwindow.current_table] = 0
            self.mainwindow.grid.sgrid[cell[0], cell[1], self.mainwindow.current_table] = ''
            self.SetCellValue(cell[0], cell[1], '')
