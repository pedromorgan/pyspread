#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright 2008 Martin Manns
# Distributed under the terms of the GNU General Public License

"""
    pyspread is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    pyspread is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys, itertools, numpy, UserDict
from types import IntType, FunctionType

DEBUG = True

class Grid(object):
    """ The central grid object that consists of 
        a string   grid sgrid and
        a function grid fgrid. """
    def __init__(self, parent, dimensions=(10,10,10)):
        global S
        S = self
        self.isrecursion = 0
        self.name = "S"
        self.dimensions = dimensions
        self.fgrid = numpy.zeros(self.dimensions, dtype="O")
        self.sgrid = numpy.zeros(self.dimensions, dtype="S")
        self.sgrid = numpy.array(self.sgrid, dtype="O")
        self.macros = Macros({}) # Macros from Macrolist

    def __getitem__(self, slice):
        self.isrecursion += 1
        fgrid_slice = self.fgrid[slice]
        if type(fgrid_slice) is FunctionType:
            fgrid_slice = numpy.array([fgrid_slice], dtype="O")
        try:
            no_different_funcs = 0
            if fgrid_slice == 0:
                self.isrecursion -= 1
                return ''
        except: pass # We got an array here
        try:
            no_different_funcs = len(set(fgrid_slice.flat) - set([0]))
        except: pass
        if no_different_funcs: # Array is not empty
            def call(func):
                functype = type(func)
                if func is 0: return 0
                elif functype is FunctionType:
                    try: res = func()
                    except Exception, x: 
                        print x
                        res = x
                    return res
                else: return func
            func_slice = numpy.array(self.fgrid[slice])
            try: func_it = func_slice.flat
            except: func_it = [func_slice]
            result = numpy.array([call(f) for f in func_it], dtype="O")
            oneele = False
            try: oneele = (len(result) == 1)
            except: pass
            if oneele: res = result[0]
            else:      res = result.reshape(func_slice.shape)
            self.isrecursion -= 1
            return res
        self.isrecursion -= 1
        return fgrid_slice
    
    def __setitem__(self, slice, value):
        self.sgrid.__setitem__(slice, value)
        return value
 
    def spread(self, x, y, z, value):
        valdim = numpy.ndim(value)
        if valdim in [1,2,3]:
            value = numpy.array(value)
            shape = value.shape
            if valdim == 1:
                S[x:x+shape[0],y,z] = numpy.array(map(repr,value.flat)).reshape(value.shape)
            elif valdim == 2:
                S[x:x+shape[0],y:y+shape[1],z] = numpy.array(map(repr,value.flat)).reshape(value.shape)
            elif valdim == 3:
                S[x:x+shape[0],y:y+shape[1],z:z+shape[2]] = numpy.array(map(repr,value.flat)).reshape(value.shape)
        elif valdim == 0:
            #res = self.__setitem__(slice(target, target, None), repr(value))
            S[x,y,z] = repr(value)
        else: print "Dimension of " + str(value) + " too high"
        self.eval_function_grid()

    def get_function_cell_indices(self):
        """ Get all fgrid cells with a function instead of dummy 0 """
        return set(zip(*numpy.nonzero(self.sgrid))+zip(*numpy.nonzero(self.fgrid)))

    def eval_function_grid(self):
        """ Eval the function grid from the string grid """
        def replace(s):
            if s in ("X", "Y", "Z"): return repr(eval(s))
            else: return s
        sgrid = self.sgrid
        string_elements = set(zip(*numpy.nonzero(sgrid))+zip(*numpy.nonzero(self.fgrid)))
        global S,X,Y,Z
        S = self
        for i in string_elements:
            X, Y, Z = i
            err = None 
            try:
                prepoc_string = "".join(replace(s) for s in sgrid[i])
                self.fgrid[i] = eval("lambda "+self.name+"=S:"+prepoc_string, globals())
            except SyntaxError, x:
                err = x
            if err is not None:    
                if '=' in sgrid[i]:
                    try:
                        stripped_string = sgrid[i].split('=',1)
                        if stripped_string[0] in ['S']:
                            raise SyntaxError, 'Cell name must not mask built-in global.' 
                        prepoc_string = "".join(replace(s) for s in stripped_string[1])
                        exec(stripped_string[0] + "=" + prepoc_string) in globals()
                        exec("global " + stripped_string[0]) in globals()
                        self.fgrid[i] = eval("lambda "+self.name+"=S:"+prepoc_string, globals())
                        err = None
                    except SyntaxError, x:
                        err = x
            if err is not None:
                self.fgrid[i] = lambda x: err

    def SetGlobalMacros(self, macros=None):
        """ Sets macros to global scope """
        if macros is None: macros = self.macros
        for macroname, macro in macros.iteritems():
            globals()[macroname] = macro

class Macros(UserDict.IterableUserDict):
    def GetMacro(self, code):
        """ Returns the function derived from the string macrocode. """
        funcname = code.split("(")[0][3:].strip()
        code = code.replace('\r\n', '\n') # Windows exec does not like Windows newline
        exec(code)
        func = eval(funcname, globals(), locals())
        func.func_dict['macrocode'] = code
        return func
        
    def AddToMacroDict(self, code):
        """ Adds a macro to the macro dict"""
        func = self.GetMacro(code)
        if func.__name__ in self:
            if DEBUG: print "Macro already present."
            return 0
        self[func.__name__] = func
        return func
